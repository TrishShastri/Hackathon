CHECKLOGIN();

function CHECKLOGIN()
{
	
	if(document.loginfrm.DLNUM.value =="DL Number")
	{
		alert("Please enter your DRIVING LICENSE NUMBER...");
		document.loginfrm.DLNUM.focus();
		return false;
	}
	
	
	return true;
}



